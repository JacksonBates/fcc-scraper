// Example
var anAdjective = "awesome!";
var ourStr = "Free Code Camp is ";
ourStr += anAdjective;

// Only change code below this line

var someAdjective = "fun";
var myStr = "Learning to code is ";

myStr += someAdjective;