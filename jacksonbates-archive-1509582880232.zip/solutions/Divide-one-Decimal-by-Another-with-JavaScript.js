var quotient = 4.4 / 2.0;


