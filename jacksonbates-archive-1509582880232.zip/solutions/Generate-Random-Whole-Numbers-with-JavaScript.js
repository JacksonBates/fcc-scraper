var randomNumberBetween0and19 = Math.floor(Math.random() * 20);

function myFunction() {

  // Only change code below this line.
  

  return Math.floor(Math.random()*10);
}
