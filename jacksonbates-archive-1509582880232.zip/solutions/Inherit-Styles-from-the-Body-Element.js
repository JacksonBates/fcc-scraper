<style>
  body {
    background-color: black;
    color:green;
    font-family:Monospace;
  }

</style>
<h1>Hello World</h1>