// Example
var array = ["John", 23];

// Only change code below this line.
var myArray = ["Jack", 33];

