function chunkArrayInGroups(arr, size) {
  // Break it up.
  var len = arr.length;
  var newArr = [];
  for (var i = 0; i < len; i = i+size) {
    newArr.push(arr.slice(i, i+size));
  }
   return newArr;
}

chunkArrayInGroups(["a", "b", "c", "d", "e", "f"], 2);
