function sumFibs(num) {
  var fibs = [1, 1];
  // num is the end of the range
  // find all the fibs until the end of the range
  while (fibs[fibs.length-1] < num) {
    fibs.push(fibs[fibs.length-1] + fibs[fibs.length-2]);
  }
  
  if (fibs[fibs.length-1] > num) {
    fibs.pop();
  }
  
  fibs = fibs.filter(function(n) {
    return n % 2 !== 0;
  });
  
  var x = 0;
  for (var i = 0; i < fibs.length-1; i++) {
    x += fibs[i];
  }
  
  return x+fibs[fibs.length-1];
}

sumFibs(1000);
