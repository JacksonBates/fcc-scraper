
function telephoneCheck(str) {
  // Good luck!
  var re = /^[1]?[ ]?(\d{3}|[(]\d{3}[)])([ ]?|[-])(\d{3}|[(]\d{3}[)])([ ]?|[-])(\d{4}|[(]\d{4}[)])$/;
  
  return str.match(re) !== null;
}



telephoneCheck("27576227382");
