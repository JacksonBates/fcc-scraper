var myMusic = [
  {
    "artist": "Billy Joel",
    "title": "Piano Man",
    "release_year": 1973,
    "formats": [ 
      "CS", 
      "8T", 
      "LP" ],
    "gold": true
  },
  // Add record here
  {
    "artist": "Warren Zevon",
    "title": "Excitable Boy",
    "release_year": 1972,
    "formats": ["LP","CS","8T"]
  }
];

