// Example
var ourName = "Free Code Camp";
var ourStr = "Hello, our name is " + ourName + ", how are you?";

// Only change code below this line
var myName = "Jackson";
var myStr = "My name is " + myName + " and I am swell!";


