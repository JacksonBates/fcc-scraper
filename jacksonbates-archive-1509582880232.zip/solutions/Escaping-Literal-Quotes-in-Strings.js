var myStr = "I am a \"double quoted\" string inside \"double quotes\""; // Change this line


