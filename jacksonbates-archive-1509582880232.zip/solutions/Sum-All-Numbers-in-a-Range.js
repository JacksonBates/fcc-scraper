function sumAll(arr) {
  arr.sort(function (a,b) {
    return a-b;
  });
  expandedArr = [];
  var sum = 0;
  var i = arr[0];
  while (i < arr[1]+1) {
    expandedArr.push(i);
    i++;
  }
  
  for (var j = 0; j < expandedArr.length; j++) {
    sum += expandedArr[j];
  }
  
  return sum;
}



sumAll([5,10]);
