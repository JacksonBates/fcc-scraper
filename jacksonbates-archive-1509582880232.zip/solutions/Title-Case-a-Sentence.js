function titleCase(str) {
  var arr = [];
  str = str.split(" ");
  for (var i = 0; i < str.length; i++) {
    var tmp = str[i].split("");
    for (var j = 0; j < tmp.length; j++) {
      if (j === 0) {
        tmp[j] = tmp[j].toUpperCase();
      } else {
        tmp[j] = tmp[j].toLowerCase();
      }
    }
    tmp.join("");
    arr.push(tmp);
  }
  arr = arr.join(" ");
  arr = arr.replace(/,/g,"");
  return arr;
      

        
    }

    titleCase("sHoRt AnD sToUt");
