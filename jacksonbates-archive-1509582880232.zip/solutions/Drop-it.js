function dropElements(arr, func) {
  // Drop them elements.
  var myFunc = arguments[1];
  
  while (!myFunc(arr[0])) {
    arr.shift();
  }
  
  return arr;
}

dropElements([1, 2, 3, 4], function(n) {return n >= 3;});
