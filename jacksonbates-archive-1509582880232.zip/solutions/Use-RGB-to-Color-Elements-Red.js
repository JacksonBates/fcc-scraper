<style>
  body {
    background-color: rgb(255, 0,0);
  }
</style>
