function pairElement(str) {
  var basePairs = {
    "A":"T",
    "T":"A",
    "C":"G",
    "G":"C"
  };
  
  var arr = [];
  
  for (var i = 0; i < str.length; i++) {
    arr.push([str[i], basePairs[str[i]]]);
  }
  
  return arr;
}

pairElement("GCG");
