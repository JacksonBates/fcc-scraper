var myList = [["Chocs",5],["tea",1],["potatoes",4],["eggs",12],["milk",1]];


