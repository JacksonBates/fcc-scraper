<style>
  body {
    background-color: rgb(0, 255, 0);
  }
</style>
