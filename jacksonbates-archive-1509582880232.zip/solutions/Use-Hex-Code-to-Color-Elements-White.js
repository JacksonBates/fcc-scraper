<style>
  body {
    background-color: #FFFFFF;
  }
</style>
