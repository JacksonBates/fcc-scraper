function findElement(arr, func) {
  var num = 0;
  
  arr = arr.filter(function(num) {return num % 2 === 0; });
  
  
  return arr[0];
}

findElement([1, 2, 3, 4], function(num){ return num % 2 === 0; });
