function addTogether() {
  var arr = Array.from(arguments);
  if (arr.length === 2 
      && typeof arr[0] === 'number'
      && typeof arr[1] === 'number') {
    return arr[0] + arr[1];
  } else if (arr.length === 1
            && typeof arr[0] !== 'number') {
      return undefined;
  } else if (arr.length === 2 
      && typeof arr[0] === 'number'
      && typeof arr[1] !== 'number'){
    return undefined;
    
  }
  return function(number) {
    function isNum(number) {
      return typeof number === 'number';
    }
    if (isNum(number)) {
      return 2 + number;
    } 
    };
  return undefined;
  
  
  
}
addTogether(2,"3");
