function repeatStringNumTimes(str, num) {
  // repeat after me
  var arrStr = [];
  for (var i = 0; i < num; i++) {
    arrStr.push(str);
  }
  /*while (newStr.length <= str.length * num) {
    newStr =+ str;
  }*/
  str = arrStr.join("");
  return str;
}

repeatStringNumTimes("abc", 3);
