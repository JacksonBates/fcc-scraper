<style>
  body {
    background-color: black;
    font-family: Monospace;
    color: green;
  }
  .pink-text {
    color: pink;
  }
  .blue-text {
    color:blue;
  }
</style>
<h1 class="pink-text blue-text">Hello World!</h1>
