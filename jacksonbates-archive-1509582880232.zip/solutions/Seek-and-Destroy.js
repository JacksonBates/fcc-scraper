function destroyer(arr) {
  // Remove all the values
  
  var firstArr = arguments[0];
  var args = [];
  
  for (var i=1; i < arguments.length; i++) {
    args.push(arguments[i]);
  }
  
  var filtered = firstArr.filter(function(e){return args.indexOf(e) === -1; });
  
  return filtered;
  
}   

destroyer([1, 2, 3, 1, 2, 3], 2, 3);
