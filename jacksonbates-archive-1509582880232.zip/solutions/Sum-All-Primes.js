function sumPrimes(num) {
  
  function isPrime(x) {
    var n = 3;
    while (n < x) {
      if (x % n === 0) {
        return false;
      } else {
        n += 2;
      }
    }
    return true;
  }
  
  var primes = [2];
  
  for (var i = 3; i <= num; i += 2) {
    if (isPrime(i)) {
      primes.push(i);
    }
  }
  

  
  var sum = 0;
  
  for (var j = 0; j < primes.length - 1; j++) {
    sum += primes[j];
  }
  
  return sum + primes[primes.length-1];
}

sumPrimes(977);
