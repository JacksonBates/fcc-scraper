var myStr = "\\ \t \t \r \n"; // Change this line


