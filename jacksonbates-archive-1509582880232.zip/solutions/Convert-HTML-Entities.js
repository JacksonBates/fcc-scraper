function convertHTML(str) {
  // &colon;&rpar;
  var ents = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "\'": "&apos;"
  };
  
  str = str.replace(/&|<|>|\"|\'/g, function(x) {
    return ents[x];
  });
  
  return str;
}

convertHTML('"');
