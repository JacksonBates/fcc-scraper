// jshint esversion:6
'use strict';

function sym(args) {
  
  // creates an array of arrays drawn from 
  // the arguments passed to sym(args)
  let arrays = [];
  for (let i = 0; i < arguments.length; i++) {
    arrays.push(arguments[i]);
  }
  
  // simple case, two arrays...
  // While arrays > 1
  // concatenate one and two, sort numerically 
  // delete dupes
  
  while (arrays.length > 1) {
    let a = arrays[0];
    let b = arrays[1];
    let newArr = a.filter(x => b.indexOf(x) < 0)
                  .concat(b.filter(x => a.indexOf(x) < 0));
    arrays.splice(0,2,newArr.sort());
    
  }
  
  let result = arrays[0].filter((elem, ind, arr) => elem !== arr[ind+1]);
  
  console.log(result);
  return result;
  
}

sym([1, 2, 3], [5, 2, 1, 4]);
