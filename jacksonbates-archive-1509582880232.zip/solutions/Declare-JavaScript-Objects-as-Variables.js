var car = {
  "wheels":4,
  "engines":1,
  "seats":5
};

var motorBike = {

  // Only change code below this line.
  "wheels":2,
  "engines":1,
  "seats":1,

};
