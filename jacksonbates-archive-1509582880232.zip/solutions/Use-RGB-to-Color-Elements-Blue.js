<style>
  body {
    background-color: rgb(0, 0, 255);
  }
</style>
