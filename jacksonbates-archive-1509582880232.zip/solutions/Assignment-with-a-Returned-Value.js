// Example
var changed = 0;

function change(num) {
  return (num + 5) / 3;
}

changed = change(10);

// Setup
var processed = 0;

function process(num) {
  return (num + 3) / 5;
}

// Only change code below this line
processed = process(7);

