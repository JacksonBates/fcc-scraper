// Example
function ourFunction(isItTrue) {
  if (isItTrue) { 
    return "Yes, it's true";
  }
  return "No, it's false";
}

// Setup
function myFunction(wasThatTrue) {

  // Only change code below this line.
  if (wasThatTrue) {
    return "That was true";
  }
  return "That was false";
  
  
  // Only change code above this line.

}

// Change this value to test
myFunction(true);
