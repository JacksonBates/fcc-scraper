// Setup
var myArray = [];

// Only change code below this line.

var i = 0;
while(i<5) {
  myArray.push(i);
  i++;
}
