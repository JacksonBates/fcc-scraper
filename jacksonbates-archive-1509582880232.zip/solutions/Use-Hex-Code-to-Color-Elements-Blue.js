<style>
  body {
    background-color: #0000FF;
  }
</style>
