// Example
function ourFunction(a, b) {
  console.log(a - b);
}
ourFunction(10, 5); // Outputs 5

// Only change code below this line.
function myFunction(a, b) {
  console.log(a + b);
}

myFunction(1,1);

