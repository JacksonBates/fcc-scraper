
function palindrome(str) {
  var regex = /[^A-Za-z0-9]/g;
  str = str.toLowerCase().replace(regex, '');
  return (str.split('').reverse().join('') === str);
}



palindrome("1 eye for of 1 eye.");
