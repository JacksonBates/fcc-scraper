function truncateString(str, num) {
  // Clear out that junk in your trunk
  if (num <= 3) {
    trunc = str.slice(0, num) + "..."; 
  } else if (str.length <= num) {
    trunc = str;
  } else {
    trunc = str.slice(0, num-3) + "...";
  }
  return trunc;
}

truncateString("A-tisket a-tasket A green and yellow basket", "A-tisket a-tasket A green and yellow basket".length + 2);
