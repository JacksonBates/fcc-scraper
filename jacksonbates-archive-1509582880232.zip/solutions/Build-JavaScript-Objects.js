// Example
var ourDog = {
  "name": "Camper",
  "legs": 4,
  "tails": 1,
  "friends": ["everything!"]
};

// Only change code below this line.

var myDog = {
  "name": "Penny",
  "legs": 4,
  "tails": 1,
  "friends": ["Elsa", "Mum"]
};
