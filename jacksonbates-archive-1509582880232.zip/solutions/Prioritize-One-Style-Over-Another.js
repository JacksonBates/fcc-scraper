<style>
  body {
    background-color: black;
    font-family: Monospace;
    color: green;
  }
  .pink-text {
    color:pink;
  }
</style>
<h1 class="pink-text">Hello World!</h1>
