<style>
  body {
    background-color: #FF0000;
  }
</style>
