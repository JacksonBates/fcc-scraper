<style>
  body {
    background-color: #F00;
  }
</style>
