/*jshint esnext: true */

function uniteUnique(arr) {
  let arrays = [];
  for (let i = 0; i < arguments.length; i++) {
    arrays.push(arguments[i]);
  }
  
//   let newArr = arrays[0].concat(arrays[1], arrays[2]);
  
  let newArr = [];
  
  for (let arraysIndex = 0; arraysIndex < arrays.length; arraysIndex++) {
    for (let arrayIndex = 0; arrayIndex < arrays[arraysIndex].length; arrayIndex++) {
      newArr.push(arrays[arraysIndex][arrayIndex]);
    }
  }
  
  for (let j = newArr.length -1; j > 0; j--) {
    if (newArr.indexOf(newArr[j]) !== j) {
      newArr.splice(j, 1);
    }
  }
  
  return newArr;
}

uniteUnique([1, 2, 3], [5, 2, 1, 4], [2, 1], [6, 7, 8]);
