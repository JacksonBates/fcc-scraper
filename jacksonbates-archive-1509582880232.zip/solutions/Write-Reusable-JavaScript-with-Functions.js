// Example
function ourFunction() {
  console.log("Heyya, World");
}

ourFunction();

// Only change code below this line
function myFunction() {
  console.log("Hi World");
}

myFunction();
