function mutation(arr) {
  // for each letter in arr[1] check if the indexOf arr[0] is < 0 if so, return false
  var secondElement = arr[1].toLowerCase().split("");
  for (var i = 0; i < secondElement.length; i++) {
    if (arr[0].toLowerCase().indexOf(secondElement[i]) < 0) {
      return false;
    }
  }
  return true;
}

mutation(["hello", "he"]);
