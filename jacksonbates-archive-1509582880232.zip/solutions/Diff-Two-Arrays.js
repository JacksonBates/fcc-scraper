function diffArray(arr1, arr2) {
  var newArr = [];
  // Same, same; but different.
  newArr = arr1.concat(arr2);
  newArr.sort();
  
  function checkArrays(value, index, array) {
    if (arr1.indexOf(value) !== -1 && arr2.indexOf(value) !== -1) {
      return false;
    } else {
      return true;
    }
  }
  
  newArr = newArr.filter(checkArrays);
  
  return newArr;
}

diffArray([1, 2, 3, 5], [1, 2, 3, 4, 5]);
