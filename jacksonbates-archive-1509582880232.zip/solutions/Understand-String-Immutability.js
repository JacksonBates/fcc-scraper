// Setup
var myStr = "Jello World";

// Only change code below this line

myStr = "Hello World"; // Fix Me


