var oldArray = [1,2,3,4,5];

// Only change code below this line.

var newArray = oldArray.map(function(val) { 
  return val + 3;
});