
function factorialize(num) {
  var factorial = 1;
  while (num > 0) {
    factorial *= num;
    num--;
  }
  return factorial;
//   var factorial = 1;
//   for (var i = 1; i < num+1; i++) {
//     factorial *= i ;
//     console.log(factorial);
//   }
//   return factorial;
}

factorialize(5);
