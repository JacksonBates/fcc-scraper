var Car = function() {
  this.wheels = 4;
  this.engines = 1;
  this.seats = 1;
};

// Only change code below this line.

var myCar = new Car();

myCar.nickname = "YOX";
