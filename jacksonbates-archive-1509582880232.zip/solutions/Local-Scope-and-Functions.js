function myFunction() {
  'use strict';
  var myVar = 2;
  
  console.log(myVar);
}
myFunction();

// run and check the console 
// myVar is not defined outside of myFunction


// now remove the console log line to pass the test

