function bouncer(arr) {
  // Don't show a false ID to this bouncer.
  function nonFalsy(value) {
    return Boolean(value);
  } 
  
  return arr.filter(nonFalsy);
}

bouncer([7, "ate", "", false, 9]);
