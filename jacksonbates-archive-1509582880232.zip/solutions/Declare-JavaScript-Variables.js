// Example
var ourName;

// Define myName below this line

var myName;
