function smallestCommons(arr) {

  function isPrime(candidate) {
    var divisor = 3;
    while (divisor < candidate) {
      if (candidate % divisor === 0 || candidate % 2 === 0) {
        return false;
      } else {
        divisor += 2;
      }
    }
    return true;
  }

  // Put the numbers from largest to smallest
  if (arr[0] < arr[1]) {
    arr.sort(function(a, b) {
    return a + b; // = [5,1]
  });
  }

  // create an array to fill in the missing numbers
  var expArr = []; 

  //Fill in the missing numbers
  for (var i = arr[0]; i >= arr[1]; i--) {
    expArr.push(i);
  }
  var primes = [2, 3, 5, 7, 11, 13, 17, 19]; // Hardcoded primes -- whatchagonnadoboutit? 
  var primeFacs = [];

  // INSERT MAGIC

  // Determine primeFacs and push them to the array
  // for each number in expArr = n,

  for (var arrIndex = 0; arrIndex < expArr.length; arrIndex++) {
    // check if n isPrime -> yes, return n as prime Fac
    var n = expArr[arrIndex];
    var tempArr = [];
    while (n > 1) {
      if (isPrime(n)) {
        tempArr.push(n);
        n = 0;
      } else {
        var primesIndex = 0;
        while (primesIndex < primes.length) {
          if (n % primes[primesIndex] === 0) {
            // put primes[k] in temp
            tempArr.push(primes[primesIndex]);
            n = n / primes[primesIndex];
          } else {
            primesIndex++;
          }
        }
      }
    }
    primeFacs.push(tempArr); // don't touch anything, it works. After several days, it works. 
  }
  primeFacs.pop(); // clears the blank array representing 1

  // create an array of objects counting the 
  // number of repeated elements in each of the primeFacs arrays

  var countsArr = [];

  for (var pfidx = 0; pfidx < primeFacs.length; pfidx++) {
    var counts = {};
    for (var pfs = 0; pfs < primeFacs[pfidx].length; pfs++) {
      var num = primeFacs[pfidx][pfs];
      if (counts[num]) {
        counts[num]++;
      } else {
        counts[num] = 1;
      }
    }
    countsArr.push(counts);
  }

  // make an array that contains only the individual primes and the highest count
  
  var finalCounts = [];

  for (var obj = 0; obj < countsArr.length; obj++) {
    for (var key = 0; key < Object.keys(countsArr[obj]).length; key++) {
      var number = Object.keys(countsArr[obj])[key];
      if (!finalCounts.includes(number)) {
        finalCounts.push(number, countsArr[obj][number]);
      } else if (finalCounts.includes(number)) {
        var current = finalCounts.indexOf(number) + 1;
        var potential = countsArr[obj][number];
        if (finalCounts[current] < potential) {
          finalCounts[current] = potential;
        }
      }
    }
  }
  
  // create an array that has all the PrimeFacs occuring as frequently
  // as needed, rather than adjacent to their 'count'
  
  var expandedPrimeFacs = [];
  
  for (var fCIdx = 0; fCIdx < finalCounts.length; fCIdx += 2) {
    for (var multiply = 0; multiply < finalCounts[fCIdx + 1]; multiply++) {
      expandedPrimeFacs.push(parseInt(finalCounts[fCIdx]));
    }
  }

  // return that, using reduce to multiply them all together
  return expandedPrimeFacs.reduce(function(a,b) {return a * b;});

}

smallestCommons([1,25]);