function myReplace(str, before, after) {
  var arr = str.split(' ');
  
  function isUpper(n){
    if (n === n.toUpperCase()) {
      return true;
    } else {
      return false;
  }
  }
  
  if (isUpper(before[0])) {
    var aftArr = after.split('');
    aftArr[0] = aftArr[0].toUpperCase();
    after = aftArr.join('');
  } 
  
  var index = arr.indexOf(before);
  
  arr.splice(index, 1, after);
  
  str = arr.join(' ');
  
  return str;
}

myReplace("A quick brown fox jumped over the lazy dog", "jumped", "leaped");
