console.log(typeof "");
console.log(typeof 0);
console.log(typeof []);
console.log(typeof {});



