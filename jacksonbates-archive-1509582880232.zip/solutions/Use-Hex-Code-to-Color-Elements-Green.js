<style>
  body {
    background-color: #00FF00;
  }
</style>
