function spinalCase(str) {
  // "It's such a fine line between stupid, and clever."
  // --David St. Hubbins
  str = str.replace(/\s+|_/g, "-");
  str = str.replace(/[A-Z]\B/g, function(x) {
    return "-" + x;
  });
  str = str.replace(/^-/, "");
  str = str.toLowerCase();
  str = str.replace(/--/g, "-");
  
  return str;
}

spinalCase('This Is Spinal Tap');
