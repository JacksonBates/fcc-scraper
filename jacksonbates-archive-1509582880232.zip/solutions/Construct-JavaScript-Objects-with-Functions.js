var Car = function() {
  this.wheels = 4;
  this.engines = 1;
  this.seats = 1;
};

// Only change code below this line.

var MotorBike = function() {
  this.wheels = 2;
  this.engines = 1;
  this.seats = 1;

};
