<style>
  body {
    background-color: #FFA500;
  }
</style>
