var string = "Split me into an array";
var array = [];

// Only change code below this line.

array = string.split(" ");
