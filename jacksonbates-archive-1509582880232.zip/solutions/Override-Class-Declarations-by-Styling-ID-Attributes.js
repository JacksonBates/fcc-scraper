<style>
  body {
    background-color: black;
    font-family: Monospace;
    color: green;
  }
  .pink-text {
    color: pink;
  }
  .blue-text {
    color: blue;
  }
  #orange-text {
    color:orange;
  }
</style>
<h1 id="orange-text" class="pink-text blue-text">Hello World!</h1>
