function steamrollArray(arr) {
  // I'm a steamroller, baby
  
  var newArr = [];
  
  function numberExtract(arr) {
    for (var i = 0; i < arr.length; i++) {
      if (!Array.isArray(arr[i])) {
        newArr.push(arr[i]);
      } else {
        numberExtract(arr[i]);
      }
    }
  }
  
  numberExtract(arr);
  
  return newArr; 
  
}

steamrollArray([1, {}, [3, [[4]]]]);
