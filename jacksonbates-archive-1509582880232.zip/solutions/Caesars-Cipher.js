function rot13(str) { // LBH QVQ VG!
  
  var chars = [];
  
  var newStr = "";
  
  for (var i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) < 65 || str.charCodeAt(i) > 90) {
      chars.push(str.charCodeAt(i));
    } else if (str.charCodeAt(i) > 77 && str.charCodeAt(i) < 91){
      chars.push(str.charCodeAt(i) - 13);
    } else {
      chars.push(str.charCodeAt(i) + 13);
    }
  }

  for (var j = 0; j < str.length; j++) {
    newStr += String.fromCharCode(chars[j]);
  }
  
  return newStr;
}

// Change the inputs below to test
rot13("SERR PBQR PNZC");
