// Example
var firstName = "Alan";
var lastName = "Turing";

// Only change code below this line

var myFirstName = "Jackson";
var myLastName = "Bates";

