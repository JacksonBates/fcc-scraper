function myFunction() {

  // Only change code below this line.

  return Math.random();

  // Only change code above this line.
}
