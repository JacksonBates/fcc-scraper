<style>
  body {
    background-color: #808080;
  }
</style>
