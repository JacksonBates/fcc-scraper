function translatePigLatin(str) {
  function isCons(n){
    switch (true){
      case (n === "a"):
      case (n === "e"):
      case (n === "i"):
      case (n === "o"):
      case (n === "u"):
        return false;
      default:
        return true;
    }
  }
  
  var ending = "";
  
  if (isCons(str[0]) && isCons(str[1]) && isCons(str[2])) {
    //put those three cons at the end of the string and add 'ay'
    ending = str.substr(0,3) + "ay";
    str = str.substr(3, str.length-1);
  } else if (isCons(str[0]) && isCons(str[1])) {
    // put those two cons at the end of the string and add 'ay'
    ending = str.substr(0,2) + "ay";
    str = str.substr(2, str.length-1);
  } else if (isCons(str[0])) {
    // ditto 1 cons
    ending = str.substr(0,1) + "ay";
    str = str.substr(1, str.length-1);
  } else {
    // put 'way' at the end
    ending = "way";
  }
  
  str += ending;
  
  return str;
}


translatePigLatin("california");
